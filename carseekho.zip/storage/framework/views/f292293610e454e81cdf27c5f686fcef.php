

<?php $__env->startSection('content'); ?>

    <div class="jumbotron">
        <h1>Hi</h1>

        <p>hello</p>

        <p><a class="btn btn-primary btn-lg" href="#" role="button"> three</a></p>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\carseekho\resources\views/helloworld.blade.php ENDPATH**/ ?>