<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('website/index');
});

Route::get('/contact', function () {return view('website/contact');});
Route::get('/features', function () {return view('website/feature');});
Route::get('/courses', function () {return view('website/courses');});
Route::get('/appointment', function () {return view('website/appointment');});
Route::get('/about-us', function () {return view('website/about');});
Route::get('/team', function () {return view('website/team');});
Route::get('/testimonial', function () {return view('website/testimonial');});
Route::get('/register', function () {return view('register');});

//Login & Register

Route::get('/login', function () {return view('login');});
Route::get('/registration', function () {return view('registration');});
