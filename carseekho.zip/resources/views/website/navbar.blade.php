<a href="/" class="navbar-brand d-flex align-items-center border-end px-4 px-lg-5">
    <h2 class="m-0"><i class="fa fa-car text-primary me-2"></i>Car Seekho</h2>
</a>

<button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
    <span class="navbar-toggler-icon"></span>
</button>
        
<div class="collapse navbar-collapse" id="navbarCollapse">
    <div class="navbar-nav ms-auto p-4 p-lg-0"> 
        <a href="/" class="nav-item nav-link active">Home</a>
        <a href="/about-us" class="nav-item nav-link">About</a>
        <a href="/courses" class="nav-item nav-link">Courses</a>
        <div class="nav-item dropdown">
            <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
            <div class="dropdown-menu bg-light m-0">
                <a href="/features" class="dropdown-item">Features</a>
                <a href="/appointment" class="dropdown-item">Appointment</a>
                <a href="/team" class="dropdown-item">Our Team</a>
                <a href="/testimonial" class="dropdown-item">Testimonial</a>
                <!-- <a href="404.html" class="dropdown-item">404 Page</a> -->
            </div>
        </div>
        <a href="/contact" class="nav-item nav-link">contact</a>
        <a href="/login" class="nav-item nav-link">Login / Register</a>
    </div>
    <a href="" class="btn btn-primary py-4 px-lg-5 d-none d-lg-block">Get Started<i class="fa fa-arrow-right ms-3"></i></a>
</div>

<!-- <script src="{{ asset('js/jquery.min.js') }}"></script>
<script type="text/javascript">
   $(function(){
    var current = location.pathname;
    $('a').each(function(){
        var $this = $(this);
        // if the current path is like this link, make it active
        if($this.attr('href').indexOf(current) !== -1){
            $this.addClass('active');
        }
    })
})
</script>  -->
        
  
    